#include <stdio.h>
#include <stdlib.h>

#define MAX 100

// Huffman tree node
struct MinHeapNode {
char data;
unsigned freq;
struct MinHeapNode *left, *right;
};

// Min Heap
struct MinHeap {
unsigned size;
unsigned capacity;
struct MinHeapNode **array;
};

// Create new node
struct MinHeapNode* newNode(char data, unsigned freq) {
struct MinHeapNode* temp =
(struct MinHeapNode*)malloc(sizeof(struct MinHeapNode));
temp->data = data;
temp->freq = freq;
temp->left = temp->right = NULL;
return temp;
}

// Create Min Heap
struct MinHeap* createMinHeap(unsigned capacity) {
struct MinHeap* minHeap =
(struct MinHeap*)malloc(sizeof(struct MinHeap));
minHeap->size = 0;
minHeap->capacity = capacity;
minHeap->array =
(struct MinHeapNode**)malloc(capacity * sizeof(struct MinHeapNode*));
return minHeap;
}

// Swap nodes
void swapMinHeapNode(struct MinHeapNode** a, struct MinHeapNode** b) {
struct MinHeapNode* t = *a;
*a = *b;
*b = t;
}

// Heapify
void minHeapify(struct MinHeap* minHeap, int idx) {
int smallest = idx;
int left = 2 * idx + 1;
int right = 2 * idx + 2;

if (left < minHeap->size &&
minHeap->array[left]->freq < minHeap->array[smallest]->freq)
smallest = left;

if (right < minHeap->size &&
minHeap->array[right]->freq < minHeap->array[smallest]->freq)
smallest = right;

if (smallest != idx) {
swapMinHeapNode(&minHeap->array[smallest],
&minHeap->array[idx]);
minHeapify(minHeap, smallest);
}
}

// Extract minimum
struct MinHeapNode* extractMin(struct MinHeap* minHeap) {
struct MinHeapNode* temp = minHeap->array[0];
minHeap->array[0] = minHeap->array[minHeap->size - 1];
minHeap->size--;
minHeapify(minHeap, 0);
return temp;
}

// Insert node
void insertMinHeap(struct MinHeap* minHeap,
struct MinHeapNode* minHeapNode) {
int i;
minHeap->size++;
i = minHeap->size - 1;

while (i && minHeapNode->freq <
minHeap->array[(i - 1) / 2]->freq) {
minHeap->array[i] = minHeap->array[(i - 1) / 2];
i = (i - 1) / 2;
}
minHeap->array[i] = minHeapNode;
}

// Build Min Heap
struct MinHeap* buildMinHeap(char data[], int freq[], int size) {
struct MinHeap* minHeap = createMinHeap(size);
int i;

for (i = 0; i < size; i++)
minHeap->array[i] = newNode(data[i], freq[i]);

minHeap->size = size;

for (i = (minHeap->size - 2) / 2; i >= 0; i--)
minHeapify(minHeap, i);

return minHeap;
}

// Build Huffman Tree
struct MinHeapNode* buildHuffmanTree(char data[], int freq[], int size) {
struct MinHeapNode *left, *right, *top;
struct MinHeap* minHeap = buildMinHeap(data, freq, size);

while (minHeap->size > 1) {
left = extractMin(minHeap);
right = extractMin(minHeap);

top = newNode('$', left->freq + right->freq);
top->left = left;
top->right = right;

insertMinHeap(minHeap, top);
}
return extractMin(minHeap);
}

// Print Huffman Codes
void printCodes(struct MinHeapNode* root, int arr[], int top) {
int i;
if (root->left) {
arr[top] = 0;
printCodes(root->left, arr, top + 1);
}
if (root->right) {
arr[top] = 1;
printCodes(root->right, arr, top + 1);
}
if (!root->left && !root->right) {
printf("%c: ", root->data);
for (i = 0; i < top; i++)
printf("%d", arr[i]);
printf("\n");
}
}

// Huffman Coding
void HuffmanCodes(char data[], int freq[], int size) {
struct MinHeapNode* root;
int arr[MAX], top = 0;

root = buildHuffmanTree(data, freq, size);
printCodes(root, arr, top);
}

// Main
int main() {
int n, i;
char data[MAX];
int freq[MAX];

printf("Enter number of characters: ");
scanf("%d", &n);

for (i = 0; i < n; i++) {
printf("Enter character %d: ", i + 1);
scanf(" %c", &data[i]);
printf("Enter frequency of %c: ", data[i]);
scanf("%d", &freq[i]);
}

printf("\nHuffman Codes are:\n");
HuffmanCodes(data, freq, n);

return 0;
}
