#include <stdio.h>

// Function to sort array (simple bubble sort for demo)
void sort(int a[], int n) {
int i, j, temp;
for (i = 0; i < n - 1; i++) {
for (j = 0; j < n - i - 1; j++) {
if (a[j] > a[j + 1]) {
temp = a[j];
a[j] = a[j + 1];
a[j + 1] = temp;
}
}
}
}

// Function to print heap
void printHeap(int a[], int n) {
int i;
printf("[");
for (i = 0; i < n; i++) {
printf("%d", a[i]);
if (i != n - 1)
printf(", ");
}
printf("]\n");
}

int main() {
int heap[10] = {10, 3, 15, 6, 8};
int n = 5;
int i;

printf("Initial Heap: ");
sort(heap, n);
printHeap(heap, n);

printf("Minimum Element: %d\n", heap[0]);

// Extract-Min
for (i = 0; i < n - 1; i++)
heap[i] = heap[i + 1];
n--;

printf("After Extract-Min: ");
printHeap(heap, n);

// Decrease-Key (15 → 2)
for (i = 0; i < n; i++) {
if (heap[i] == 15) {
heap[i] = 2;
break;
}
}

sort(heap, n);
printf("After Decrease-Key(15→2): ");
printHeap(heap, n);

printf("New Minimum: %d\n", heap[0]);

return 0;
}
