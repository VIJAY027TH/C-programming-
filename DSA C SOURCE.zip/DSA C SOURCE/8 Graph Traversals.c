#include <stdio.h>
#define MAX 20

int adj[MAX][MAX];
int visited[MAX];
int n;

// Queue for BFS
int queue[MAX], front = -1, rear = -1;

void enqueue(int v) {
if (rear == MAX - 1)
printf("Queue Overflow\n");
else {
if (front == -1)
front = 0;
queue[++rear] = v;
}
}

int dequeue() {
if (front == -1 || front > rear)
return -1;
return queue[front++];
}

// Breadth First Search (BFS)
void BFS(int start) {
int i, v;
for (i = 0; i < n; i++)
visited[i] = 0;

front = rear = -1;   // reset queue

enqueue(start);
visited[start] = 1;

printf("BFS Traversal: ");
while ((v = dequeue()) != -1) {
printf("%d ", v);
for (i = 0; i < n; i++) {
if (adj[v][i] == 1 && visited[i] == 0) {
enqueue(i);
visited[i] = 1;
}
}
}
printf("\n");
}

// Depth First Search (DFS)
void DFS(int v) {
int i;
printf("%d ", v);
visited[v] = 1;

for (i = 0; i < n; i++) {
if (adj[v][i] == 1 && visited[i] == 0)
DFS(i);
}
}

int main() {
int i, j, start;

printf("Enter number of vertices: ");
scanf("%d", &n);

printf("Enter adjacency matrix (%d x %d):\n", n, n);
for (i = 0; i < n; i++) {
for (j = 0; j < n; j++) {
scanf("%d", &adj[i][j]);
}
}

printf("Enter starting vertex (0 to %d): ", n - 1);
scanf("%d", &start);

BFS(start);

for (i = 0; i < n; i++)
visited[i] = 0;

printf("DFS Traversal: ");
DFS(start);
printf("\n");

return 0;
}
