#include <stdio.h>
#include <limits.h>

#define MAX 100

int MatrixChainOrder(int p[], int n) {
int m[MAX][MAX];
int i, j, k, L;

// Cost is zero when multiplying one matrix
for (i = 1; i < n; i++)
m[i][i] = 0;

// L is chain length
for (L = 2; L < n; L++) {
for (i = 1; i < n - L + 1; i++) {
j = i + L - 1;
m[i][j] = INT_MAX;

for (k = i; k <= j - 1; k++) {
int q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j];
if (q < m[i][j])
m[i][j] = q;
}
}
}

return m[1][n - 1];
}

int main() {
int n, i;
int p[MAX];

printf("Enter number of matrices: ");
scanf("%d", &n);

printf("Enter dimensions (p0 p1 p2 ... pn): ");
for (i = 0; i <= n; i++)
scanf("%d", &p[i]);

int minCost = MatrixChainOrder(p, n + 1);

printf("\nMinimum number of multiplications is: %d\n", minCost);

return 0;
}
