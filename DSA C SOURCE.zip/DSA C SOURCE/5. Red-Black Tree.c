#include <stdio.h>
#include <stdlib.h>

#define RED 0
#define BLACK 1

// Structure for a node
struct Node {
int data, color;
struct Node *left, *right, *parent;
};

// Create a new node
struct Node* createNode(int data) {
struct Node* node = (struct Node*)malloc(sizeof(struct Node));
node->data = data;
node->color = RED;
node->left = node->right = node->parent = NULL;
return node;
}

// Left rotation
void rotateLeft(struct Node **root, struct Node *x) {
struct Node *y = x->right;
x->right = y->left;

if (y->left != NULL)
y->left->parent = x;

y->parent = x->parent;

if (x->parent == NULL)
*root = y;
else if (x == x->parent->left)
x->parent->left = y;
else
x->parent->right = y;

y->left = x;
x->parent = y;
}

// Right rotation
void rotateRight(struct Node **root, struct Node *y) {
struct Node *x = y->left;
y->left = x->right;

if (x->right != NULL)
x->right->parent = y;

x->parent = y->parent;

if (y->parent == NULL)
*root = x;
else if (y == y->parent->left)
y->parent->left = x;
else
y->parent->right = x;

x->right = y;
y->parent = x;
}

// Fix Red-Black Tree violations
void fixViolation(struct Node **root, struct Node *z) {
while (z->parent != NULL && z->parent->color == RED) {
struct Node *grandparent = z->parent->parent;

if (z->parent == grandparent->left) {
struct Node *uncle = grandparent->right;

if (uncle != NULL && uncle->color == RED) {
z->parent->color = BLACK;
uncle->color = BLACK;
grandparent->color = RED;
z = grandparent;
} else {
if (z == z->parent->right) {
z = z->parent;
rotateLeft(root, z);
}
z->parent->color = BLACK;
grandparent->color = RED;
rotateRight(root, grandparent);
}
} else {
struct Node *uncle = grandparent->left;

if (uncle != NULL && uncle->color == RED) {
z->parent->color = BLACK;
uncle->color = BLACK;
grandparent->color = RED;
z = grandparent;
} else {
if (z == z->parent->left) {
z = z->parent;
rotateRight(root, z);
}
z->parent->color = BLACK;
grandparent->color = RED;
rotateLeft(root, grandparent);
}
}
}
(*root)->color = BLACK;
}

// Insert into Red-Black Tree
void insert(struct Node **root, int data) {
struct Node *z = createNode(data);
struct Node *y = NULL;
struct Node *x = *root;

while (x != NULL) {
y = x;
if (z->data < x->data)
x = x->left;
else
x = x->right;
}

z->parent = y;

if (y == NULL)
*root = z;
else if (z->data < y->data)
y->left = z;
else
y->right = z;

fixViolation(root, z);
}

// Inorder traversal
void inorder(struct Node *root) {
if (root == NULL)
return;

inorder(root->left);
printf("%d(%c) ", root->data, root->color == RED ? 'R' : 'B');
inorder(root->right);
}

int main() {
struct Node *root = NULL;
int n, value, i;

printf("Enter number of nodes: ");
scanf("%d", &n);

printf("Enter %d elements: ", n);
for (i = 0; i < n; i++) {
scanf("%d", &value);
insert(&root, value);
}

printf("\nInorder Traversal with Colors: ");
inorder(root);
printf("\n");

return 0;
}
