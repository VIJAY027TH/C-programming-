#include <stdio.h>

// Function to swap two elements
void swap(int *a, int *b) {
int temp = *a;
*a = *b;
*b = temp;
}

// Heapify function for Max Heap
void heapify(int arr[], int n, int i) {
int largest = i;
int left = 2 * i + 1;
int right = 2 * i + 2;

if (left < n && arr[left] > arr[largest])
largest = left;

if (right < n && arr[right] > arr[largest])
largest = right;

if (largest != i) {
swap(&arr[i], &arr[largest]);
heapify(arr, n, largest);
}
}

// Build Max Heap
void buildMaxHeap(int arr[], int n) {
int i;
for (i = n / 2 - 1; i >= 0; i--)
heapify(arr, n, i);
}

// Heap Sort
void heapSort(int arr[], int n) {
int i;
buildMaxHeap(arr, n);
for (i = n - 1; i > 0; i--) {
swap(&arr[0], &arr[i]);
heapify(arr, i, 0);
}
}

// Print array / heap
void printHeap(int arr[], int n) {
int i;
for (i = 0; i < n; i++)
printf("%d ", arr[i]);
printf("\n");
}

int main() {
int n, i;
int arr[50];

printf("Enter number of elements: ");
scanf("%d", &n);

printf("Enter %d elements: ", n);
for (i = 0; i < n; i++)
scanf("%d", &arr[i]);

printf("\nOriginal array: ");
printHeap(arr, n);

buildMaxHeap(arr, n);
printf("Max Heap: ");
printHeap(arr, n);

heapSort(arr, n);
printf("Sorted array (Heap Sort): ");
printHeap(arr, n);

return 0;
}
