#include <stdio.h>

#define MAX 50

// Structure to represent an activity
typedef struct {
int start;
int finish;
} Activity;

// Sort activities by finish time (Bubble Sort)
void sortActivities(Activity activities[], int n) {
int i, j;
Activity temp;

for (i = 0; i < n - 1; i++) {
for (j = 0; j < n - i - 1; j++) {
if (activities[j].finish > activities[j + 1].finish) {
temp = activities[j];
activities[j] = activities[j + 1];
activities[j + 1] = temp;
}
}
}
}

// Activity Selection Algorithm
void activitySelection(Activity activities[], int n) {
int i, j;

printf("\nSelected activities are:\n");

// First activity is always selected
i = 0;
printf("A%d (Start: %d, Finish: %d)\n",
i + 1, activities[i].start, activities[i].finish);

// Select remaining activities
for (j = 1; j < n; j++) {
if (activities[j].start >= activities[i].finish) {
printf("A%d (Start: %d, Finish: %d)\n",
j + 1, activities[j].start, activities[j].finish);
i = j;
}
}
}

int main() {
int n, i;
Activity activities[MAX];

printf("Enter number of activities: ");
scanf("%d", &n);

printf("Enter start and finish times of activities:\n");
for (i = 0; i < n; i++) {
printf("Activity %d - Start: ", i + 1);
scanf("%d", &activities[i].start);
printf("Activity %d - Finish: ", i + 1);
scanf("%d", &activities[i].finish);
}

sortActivities(activities, n);
activitySelection(activities, n);

return 0;
}
