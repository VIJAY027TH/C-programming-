#include <stdio.h>
#include <stdlib.h>

// Structure for a node in BST
struct Node {
int data;
struct Node *left, *right;
};

// Function to create a new node
struct Node* createNode(int value) {
struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
newNode->data = value;
newNode->left = newNode->right = NULL;
return newNode;
}

// Function to insert a node into BST
struct Node* insert(struct Node* root, int value) {
if (root == NULL)
return createNode(value);

if (value < root->data)
root->left = insert(root->left, value);
else if (value > root->data)
root->right = insert(root->right, value);

return root;
}

// Inorder Traversal
void inorder(struct Node* root) {
if (root != NULL) {
inorder(root->left);
printf("%d ", root->data);
inorder(root->right);
}
}

// Preorder Traversal
void preorder(struct Node* root) {
if (root != NULL) {
printf("%d ", root->data);
preorder(root->left);
preorder(root->right);
}
}

// Postorder Traversal
void postorder(struct Node* root) {
if (root != NULL) {
postorder(root->left);
postorder(root->right);
printf("%d ", root->data);
}
}

// Search in BST
struct Node* search(struct Node* root, int key) {
if (root == NULL || root->data == key)
return root;

if (key < root->data)
return search(root->left, key);
else
return search(root->right, key);
}

int main() {
struct Node* root = NULL;
int n, value, key, i;

printf("Enter number of nodes: ");
scanf("%d", &n);

printf("Enter %d elements: ", n);
for (i = 0; i < n; i++) {
scanf("%d", &value);
root = insert(root, value);
}

printf("\nInorder Traversal: ");
inorder(root);

printf("\nPreorder Traversal: ");
preorder(root);

printf("\nPostorder Traversal: ");
postorder(root);

printf("\n\nEnter element to search: ");
scanf("%d", &key);

if (search(root, key) != NULL)
printf("Element %d found in BST.\n", key);
else
printf("Element %d not found in BST.\n", key);

return 0;
}
