#include <stdio.h>
#include <stdlib.h>

#define MAX 100

// Structure for a tree node
struct Node {
int data;
struct Node *left, *right;
};

// Stack structure
struct Stack {
struct Node* arr[MAX];
int top;
};

// Create a new node
struct Node* newNode(int data) {
struct Node* node = (struct Node*)malloc(sizeof(struct Node));
node->data = data;
node->left = node->right = NULL;
return node;
}

// Stack operations
void push(struct Stack* s, struct Node* node) {
s->arr[++(s->top)] = node;
}

struct Node* pop(struct Stack* s) {
return s->arr[(s->top)--];
}

int isEmpty(struct Stack* s) {
return s->top == -1;
}

// Iterative Inorder Traversal
void inorderIterative(struct Node* root) {
struct Stack s;
struct Node* curr = root;
s.top = -1;

while (curr != NULL || !isEmpty(&s)) {
while (curr != NULL) {
push(&s, curr);
curr = curr->left;
}
curr = pop(&s);
printf("%d ", curr->data);
curr = curr->right;
}
}

// Iterative Preorder Traversal
void preorderIterative(struct Node* root) {
struct Stack s;
struct Node* node;
s.top = -1;

if (root == NULL)
return;

push(&s, root);

while (!isEmpty(&s)) {
node = pop(&s);
printf("%d ", node->data);

if (node->right)
push(&s, node->right);
if (node->left)
push(&s, node->left);
}
}

// Iterative Postorder Traversal (using two stacks)
void postorderIterative(struct Node* root) {
struct Stack s1, s2;
struct Node* node;

if (root == NULL)
return;

s1.top = -1;
s2.top = -1;

push(&s1, root);

while (!isEmpty(&s1)) {
node = pop(&s1);
push(&s2, node);

if (node->left)
push(&s1, node->left);
if (node->right)
push(&s1, node->right);
}

while (!isEmpty(&s2)) {
node = pop(&s2);
printf("%d ", node->data);
}
}

// Main function
int main() {
struct Node* root = newNode(1);
root->left = newNode(2);
root->right = newNode(3);
root->left->left = newNode(4);
root->left->right = newNode(5);

printf("Inorder Traversal (Iterative): ");
inorderIterative(root);
printf("\n");

printf("Preorder Traversal (Iterative): ");
preorderIterative(root);
printf("\n");

printf("Postorder Traversal (Iterative): ");
postorderIterative(root);
printf("\n");

return 0;
}
