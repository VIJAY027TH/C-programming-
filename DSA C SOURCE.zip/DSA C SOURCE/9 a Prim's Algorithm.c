#include <stdio.h>

#define INF 9999
#define MAX 20

void prims(int G[MAX][MAX], int n) {
int visited[MAX] = {0};
int i, j, edgeCount = 0;
int minCost = 0;

visited[0] = 1;   // Start from vertex 0

printf("\nEdges in the Minimum Spanning Tree:\n");

while (edgeCount < n - 1) {
int min = INF, a = -1, b = -1;

for (i = 0; i < n; i++) {
if (visited[i]) {
for (j = 0; j < n; j++) {
if (!visited[j] && G[i][j] < min) {
min = G[i][j];
a = i;
b = j;
}
}
}
}

if (a != -1 && b != -1) {
printf("%d -> %d cost = %d\n", a, b, G[a][b]);
minCost += G[a][b];
visited[b] = 1;
edgeCount++;
}
}

printf("\nMinimum Cost of Spanning Tree: %d\n", minCost);
}

int main() {
int G[MAX][MAX], n, i, j;

printf("Enter number of vertices: ");
scanf("%d", &n);

printf("Enter the adjacency matrix:\n");
for (i = 0; i < n; i++) {
for (j = 0; j < n; j++) {
scanf("%d", &G[i][j]);
if (G[i][j] == 0 && i != j)
G[i][j] = INF;
}
}

prims(G, n);

return 0;
}
